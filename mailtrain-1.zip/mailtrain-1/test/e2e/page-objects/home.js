'use strict';

const web = require('../lib/web');

module.exports = web({
    url: '/'
});
