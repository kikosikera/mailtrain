Screenshots taken with:
https://derailer.org/paparazzi/
format=png w=1024 h=auto
