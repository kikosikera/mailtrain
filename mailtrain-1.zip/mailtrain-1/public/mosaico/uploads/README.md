# default image upload folder
