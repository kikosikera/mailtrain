# Crowdfunding Backers

Mailtrain received funding from a [crowdfunding campaign](https://www.indiegogo.com/at/mailtrain/8720095). This was to enable me to spend the time required to get automation support into Mailtrain. These are the people who contributed to this fund raiser.

  * iRedMail - free, open source mail server solution &lt;[www.iredmail.org](http://www.iredmail.org/)&gt;
  * Richard Adleta
  * Wes Bos
  * Christophe Lombart
  * Anselm Hannemann
  * Jens Carroll
  * Anonymous
  * Brett Nelson
  * Jason Pelker
  * Leif Singer
  * Eve Land
  * Diana Espino
  * Moussa Clarke
  * Carl Hauschke
